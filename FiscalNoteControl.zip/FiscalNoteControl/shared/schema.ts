import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const suppliers = pgTable("suppliers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  cnpj: varchar("cnpj", { length: 18 }).notNull().unique(),
  supplierType: varchar("supplier_type", { length: 20 }).notNull(), // 'rental', 'service', 'product'
  contractBalance: decimal("contract_balance", { precision: 15, scale: 2 }).default('0'),
  monitored: boolean("monitored").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const invoices = pgTable("invoices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  invoiceNumber: varchar("invoice_number", { length: 50 }).notNull().unique(),
  supplierId: varchar("supplier_id").notNull().references(() => suppliers.id),
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  value: decimal("value", { precision: 15, scale: 2 }).notNull(),
  invoiceType: varchar("invoice_type", { length: 20 }).notNull(), // 'contract', 'adhoc', 'rental'
  
  // Status checkboxes
  posted: boolean("posted").default(false),
  attachmentUploaded: boolean("attachment_uploaded").default(false),
  regularized: boolean("regularized").default(false),
  measurementApproved: boolean("measurement_approved").default(false),
  measured: boolean("measured").default(false),
  
  contractBalance: decimal("contract_balance", { precision: 15, scale: 2 }),
  priorityAlert: boolean("priority_alert").default(false),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  invoiceId: varchar("invoice_id").notNull().references(() => invoices.id),
  daysRemaining: integer("days_remaining").notNull(),
  alertSent: boolean("alert_sent").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const suppliersRelations = relations(suppliers, ({ many }) => ({
  invoices: many(invoices),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  supplier: one(suppliers, {
    fields: [invoices.supplierId],
    references: [suppliers.id],
  }),
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  invoice: one(invoices, {
    fields: [alerts.invoiceId],
    references: [invoices.id],
  }),
}));

// Insert schemas
export const insertSupplierSchema = createInsertSchema(suppliers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

// Combined types for API responses
export type InvoiceWithSupplier = Invoice & {
  supplier: Supplier;
};

export type SupplierWithInvoices = Supplier & {
  invoices: Invoice[];
};
