import { suppliers, invoices, alerts, type Supplier, type InsertSupplier, type Invoice, type InsertInvoice, type Alert, type InsertAlert, type InvoiceWithSupplier, type SupplierWithInvoices } from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, sql, and, or, ilike } from "drizzle-orm";

export interface IStorage {
  // Suppliers
  getSupplier(id: string): Promise<Supplier | undefined>;
  getSupplierByName(name: string): Promise<Supplier | undefined>;
  getAllSuppliers(): Promise<Supplier[]>;
  searchSuppliers(query: string): Promise<Supplier[]>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier>;
  deleteSupplier(id: string): Promise<void>;

  // Invoices
  getInvoice(id: string): Promise<InvoiceWithSupplier | undefined>;
  getAllInvoices(): Promise<InvoiceWithSupplier[]>;
  getInvoicesBySupplier(supplierId: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, invoice: Partial<InsertInvoice>): Promise<Invoice>;
  deleteInvoice(id: string): Promise<void>;

  // Alerts
  getAlertsByInvoice(invoiceId: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, alert: Partial<InsertAlert>): Promise<Alert>;

  // Dashboard metrics
  getDashboardMetrics(): Promise<{
    totalInvoices: number;
    pendingInvoices: number;
    dueSoonInvoices: number;
    totalValue: string;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Suppliers
  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier || undefined;
  }

  async getSupplierByName(name: string): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.name, name));
    return supplier || undefined;
  }

  async getAllSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).orderBy(asc(suppliers.name));
  }

  async searchSuppliers(query: string): Promise<Supplier[]> {
    return await db.select().from(suppliers)
      .where(or(
        ilike(suppliers.name, `%${query}%`),
        ilike(suppliers.cnpj, `%${query}%`)
      ))
      .orderBy(asc(suppliers.name));
  }

  async createSupplier(supplier: InsertSupplier): Promise<Supplier> {
    const [created] = await db.insert(suppliers).values({
      ...supplier,
      updatedAt: new Date()
    }).returning();
    return created;
  }

  async updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier> {
    const [updated] = await db.update(suppliers)
      .set({ ...supplier, updatedAt: new Date() })
      .where(eq(suppliers.id, id))
      .returning();
    return updated;
  }

  async deleteSupplier(id: string): Promise<void> {
    await db.delete(suppliers).where(eq(suppliers.id, id));
  }

  // Invoices
  async getInvoice(id: string): Promise<InvoiceWithSupplier | undefined> {
    const [invoice] = await db.select()
      .from(invoices)
      .leftJoin(suppliers, eq(invoices.supplierId, suppliers.id))
      .where(eq(invoices.id, id));
    
    if (!invoice || !invoice.suppliers) return undefined;

    return {
      ...invoice.invoices,
      supplier: invoice.suppliers
    };
  }

  async getAllInvoices(): Promise<InvoiceWithSupplier[]> {
    const results = await db.select()
      .from(invoices)
      .leftJoin(suppliers, eq(invoices.supplierId, suppliers.id))
      .orderBy(asc(invoices.dueDate));

    return results.map(result => ({
      ...result.invoices,
      supplier: result.suppliers!
    }));
  }

  async getInvoicesBySupplier(supplierId: string): Promise<Invoice[]> {
    return await db.select().from(invoices)
      .where(eq(invoices.supplierId, supplierId))
      .orderBy(desc(invoices.createdAt));
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const [created] = await db.insert(invoices).values({
      ...invoice,
      updatedAt: new Date()
    }).returning();

    // Update supplier contract balance if it's a contract type
    if (invoice.invoiceType === 'contract' && invoice.contractBalance) {
      await db.update(suppliers)
        .set({ 
          contractBalance: sql`${suppliers.contractBalance} - ${invoice.value}`,
          updatedAt: new Date()
        })
        .where(eq(suppliers.id, invoice.supplierId));
    }

    return created;
  }

  async updateInvoice(id: string, invoice: Partial<InsertInvoice>): Promise<Invoice> {
    const [updated] = await db.update(invoices)
      .set({ ...invoice, updatedAt: new Date() })
      .where(eq(invoices.id, id))
      .returning();
    return updated;
  }

  async deleteInvoice(id: string): Promise<void> {
    await db.delete(invoices).where(eq(invoices.id, id));
  }

  // Alerts
  async getAlertsByInvoice(invoiceId: string): Promise<Alert[]> {
    return await db.select().from(alerts)
      .where(eq(alerts.invoiceId, invoiceId))
      .orderBy(desc(alerts.createdAt));
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [created] = await db.insert(alerts).values(alert).returning();
    return created;
  }

  async updateAlert(id: string, alert: Partial<InsertAlert>): Promise<Alert> {
    const [updated] = await db.update(alerts)
      .set(alert)
      .where(eq(alerts.id, id))
      .returning();
    return updated;
  }

  // Dashboard metrics
  async getDashboardMetrics(): Promise<{
    totalInvoices: number;
    pendingInvoices: number;
    dueSoonInvoices: number;
    totalValue: string;
  }> {
    const totalInvoices = await db.select({ count: sql<number>`count(*)` }).from(invoices);
    
    const pendingInvoices = await db.select({ count: sql<number>`count(*)` })
      .from(invoices)
      .where(or(
        eq(invoices.posted, false),
        eq(invoices.attachmentUploaded, false),
        eq(invoices.regularized, false)
      ));

    const dueSoonInvoices = await db.select({ count: sql<number>`count(*)` })
      .from(invoices)
      .where(and(
        sql`${invoices.dueDate} <= NOW() + INTERVAL '5 days'`,
        sql`${invoices.dueDate} >= NOW()`
      ));

    const totalValue = await db.select({ sum: sql<string>`COALESCE(sum(${invoices.value}), 0)` }).from(invoices);

    return {
      totalInvoices: totalInvoices[0].count,
      pendingInvoices: pendingInvoices[0].count,
      dueSoonInvoices: dueSoonInvoices[0].count,
      totalValue: totalValue[0].sum
    };
  }
}

export const storage = new DatabaseStorage();
