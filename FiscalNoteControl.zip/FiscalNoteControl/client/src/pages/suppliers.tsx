import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { SupplierTable } from "@/components/suppliers/supplier-table";
import { SupplierFormModal } from "@/components/suppliers/supplier-form-modal";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { Supplier, InsertSupplier } from "@shared/schema";
import type { SupplierFormData } from "@/lib/types";

export default function Suppliers() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | undefined>();

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: suppliers = [], isLoading } = useQuery({
    queryKey: ["/api/suppliers"],
    queryFn: api.getSuppliers,
  });

  const createSupplierMutation = useMutation({
    mutationFn: (data: InsertSupplier) => api.createSupplier(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      toast({
        title: "Sucesso",
        description: "Fornecedor criado com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao criar fornecedor. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const updateSupplierMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertSupplier> }) =>
      api.updateSupplier(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      toast({
        title: "Sucesso",
        description: "Fornecedor atualizado com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar fornecedor. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleAddSupplier = () => {
    setEditingSupplier(undefined);
    setShowAddModal(true);
  };

  const handleEditSupplier = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setShowAddModal(true);
  };

  const handleViewSupplier = (supplier: Supplier) => {
    console.log("View supplier:", supplier);
  };

  const handleSubmitSupplier = (data: SupplierFormData) => {
    const supplierData: InsertSupplier = {
      name: data.name,
      cnpj: data.cnpj.replace(/\D/g, ''),
      supplierType: data.supplierType,
      contractBalance: data.contractBalance ? data.contractBalance.replace(/[^\d,]/g, '').replace(',', '.') : '0',
      monitored: data.monitored,
    };

    if (editingSupplier) {
      updateSupplierMutation.mutate({ id: editingSupplier.id, data: supplierData });
    } else {
      createSupplierMutation.mutate(supplierData);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Fornecedores"
        subtitle="Gerenciamento de fornecedores"
        onAddClick={handleAddSupplier}
        addButtonText="Novo Fornecedor"
      />

      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando fornecedores...</p>
          </div>
        ) : (
          <SupplierTable
            suppliers={suppliers}
            onEdit={handleEditSupplier}
            onView={handleViewSupplier}
          />
        )}
      </div>

      <SupplierFormModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleSubmitSupplier}
        supplier={editingSupplier}
      />
    </div>
  );
}
