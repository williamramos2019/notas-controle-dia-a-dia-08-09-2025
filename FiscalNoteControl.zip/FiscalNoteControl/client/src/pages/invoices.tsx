import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { InvoiceTable } from "@/components/invoices/invoice-table";
import { InvoiceFormModal } from "@/components/invoices/invoice-form-modal";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { InvoiceWithSupplier, InsertInvoice } from "@shared/schema";
import type { InvoiceFormData } from "@/lib/types";

export default function Invoices() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceWithSupplier | undefined>();

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: api.getInvoices,
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (data: InsertInvoice) => api.createInvoice(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Sucesso",
        description: "Nota fiscal criada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao criar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertInvoice> }) =>
      api.updateInvoice(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Sucesso",
        description: "Nota fiscal atualizada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleAddInvoice = () => {
    setEditingInvoice(undefined);
    setShowAddModal(true);
  };

  const handleEditInvoice = (invoice: InvoiceWithSupplier) => {
    setEditingInvoice(invoice);
    setShowAddModal(true);
  };

  const handleViewInvoice = (invoice: InvoiceWithSupplier) => {
    console.log("View invoice:", invoice);
  };

  const handleSubmitInvoice = (data: InvoiceFormData) => {
    const invoiceData: InsertInvoice = {
      invoiceNumber: data.invoiceNumber,
      supplierId: data.supplierId,
      issueDate: new Date(data.issueDate),
      dueDate: new Date(data.dueDate),
      value: data.value.replace(/[^\d,]/g, '').replace(',', '.'),
      invoiceType: data.invoiceType,
      posted: data.posted,
      attachmentUploaded: data.attachmentUploaded,
      regularized: data.regularized,
      measurementApproved: data.measurementApproved,
      measured: data.measured,
      contractBalance: data.contractBalance ? data.contractBalance.replace(/[^\d,]/g, '').replace(',', '.') : undefined,
      priorityAlert: false,
    };

    if (editingInvoice) {
      updateInvoiceMutation.mutate({ id: editingInvoice.id, data: invoiceData });
    } else {
      createInvoiceMutation.mutate(invoiceData);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Notas Fiscais"
        subtitle="Gerenciamento de notas fiscais"
        onAddClick={handleAddInvoice}
        addButtonText="Nova Nota"
      />

      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando notas fiscais...</p>
          </div>
        ) : (
          <InvoiceTable
            invoices={invoices}
            onEdit={handleEditInvoice}
            onView={handleViewInvoice}
          />
        )}
      </div>

      <InvoiceFormModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleSubmitInvoice}
        invoice={editingInvoice}
      />
    </div>
  );
}
