import { apiRequest } from "@/lib/queryClient";
import type { InvoiceWithSupplier, Supplier, InsertInvoice, InsertSupplier } from "@shared/schema";
import type { DashboardMetrics } from "./types";

export const api = {
  // Dashboard
  getDashboardMetrics: async (): Promise<DashboardMetrics> => {
    const response = await apiRequest("GET", "/api/dashboard/metrics");
    return response.json();
  },

  // Suppliers
  getSuppliers: async (): Promise<Supplier[]> => {
    const response = await apiRequest("GET", "/api/suppliers");
    return response.json();
  },

  searchSuppliers: async (query: string): Promise<Supplier[]> => {
    const response = await apiRequest("GET", `/api/suppliers?search=${encodeURIComponent(query)}`);
    return response.json();
  },

  createSupplier: async (supplier: InsertSupplier): Promise<Supplier> => {
    const response = await apiRequest("POST", "/api/suppliers", supplier);
    return response.json();
  },

  updateSupplier: async (id: string, supplier: Partial<InsertSupplier>): Promise<Supplier> => {
    const response = await apiRequest("PUT", `/api/suppliers/${id}`, supplier);
    return response.json();
  },

  deleteSupplier: async (id: string): Promise<void> => {
    await apiRequest("DELETE", `/api/suppliers/${id}`);
  },

  // Invoices
  getInvoices: async (): Promise<InvoiceWithSupplier[]> => {
    const response = await apiRequest("GET", "/api/invoices");
    return response.json();
  },

  createInvoice: async (invoice: InsertInvoice): Promise<InvoiceWithSupplier> => {
    const response = await apiRequest("POST", "/api/invoices", invoice);
    return response.json();
  },

  updateInvoice: async (id: string, invoice: Partial<InsertInvoice>): Promise<InvoiceWithSupplier> => {
    const response = await apiRequest("PUT", `/api/invoices/${id}`, invoice);
    return response.json();
  },

  deleteInvoice: async (id: string): Promise<void> => {
    await apiRequest("DELETE", `/api/invoices/${id}`);
  },
};
