export interface DashboardMetrics {
  totalInvoices: number;
  pendingInvoices: number;
  dueSoonInvoices: number;
  totalValue: string;
}

export interface InvoiceFilter {
  search: string;
  type: string;
  status: string;
}

export type InvoiceType = 'contract' | 'adhoc' | 'rental';
export type SupplierType = 'rental' | 'service' | 'product';

export interface InvoiceFormData {
  invoiceNumber: string;
  supplierId: string;
  issueDate: string;
  dueDate: string;
  value: string;
  invoiceType: InvoiceType;
  posted: boolean;
  attachmentUploaded: boolean;
  regularized: boolean;
  measurementApproved: boolean;
  measured: boolean;
  contractBalance?: string;
}

export interface SupplierFormData {
  name: string;
  cnpj: string;
  supplierType: SupplierType;
  contractBalance: string;
  monitored: boolean;
}
