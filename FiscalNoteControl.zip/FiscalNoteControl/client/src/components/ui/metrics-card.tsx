interface MetricsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconColor: string;
  change?: string;
  changeColor?: string;
  changeLabel?: string;
}

export function MetricsCard({ 
  title, 
  value, 
  icon, 
  iconColor, 
  change, 
  changeColor = "text-green-600", 
  changeLabel 
}: MetricsCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm" data-testid={`metric-${title.toLowerCase().replace(' ', '-')}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm font-medium">{title}</p>
          <p className="text-2xl font-bold text-foreground">{value}</p>
        </div>
        <div className={`w-12 h-12 ${iconColor} rounded-lg flex items-center justify-center`}>
          <i className={`${icon} ${iconColor.includes('blue') ? 'text-blue-600' : iconColor.includes('yellow') ? 'text-yellow-600' : iconColor.includes('red') ? 'text-red-600' : 'text-green-600'}`}></i>
        </div>
      </div>
      {change && (
        <div className="mt-4 flex items-center text-sm">
          <span className={`${changeColor} font-medium`}>{change}</span>
          {changeLabel && <span className="text-muted-foreground ml-1">{changeLabel}</span>}
        </div>
      )}
    </div>
  );
}
