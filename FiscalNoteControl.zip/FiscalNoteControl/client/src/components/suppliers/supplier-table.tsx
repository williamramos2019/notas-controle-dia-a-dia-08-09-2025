import type { Supplier } from "@shared/schema";

interface SupplierTableProps {
  suppliers: Supplier[];
  onEdit: (supplier: Supplier) => void;
  onView: (supplier: Supplier) => void;
}

export function SupplierTable({ suppliers, onEdit, onView }: SupplierTableProps) {
  const getSupplierTypeColor = (type: string) => {
    switch (type) {
      case 'rental': return 'bg-orange-100 text-orange-800';
      case 'service': return 'bg-blue-100 text-blue-800';
      case 'product': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSupplierTypeName = (type: string) => {
    switch (type) {
      case 'rental': return 'Locação';
      case 'service': return 'Serviço';
      case 'product': return 'Produto';
      default: return type;
    }
  };

  const formatCurrency = (value: string | null) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(parseFloat(value));
  };

  if (suppliers.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <i className="fas fa-building text-4xl text-muted-foreground mb-4"></i>
        <h3 className="text-lg font-medium text-foreground mb-2">Nenhum fornecedor encontrado</h3>
        <p className="text-muted-foreground">Adicione um novo fornecedor para começar.</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground">Fornecedores Cadastrados</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Nome
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">CNPJ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Tipo</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Saldo Contrato</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Monitorado</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="bg-background divide-y divide-border">
            {suppliers.map((supplier) => (
              <tr 
                key={supplier.id} 
                className="hover:bg-accent/50 transition-colors"
                data-testid={`supplier-row-${supplier.name.replace(/\s+/g, '-').toLowerCase()}`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 ${getSupplierTypeColor(supplier.supplierType).split(' ')[0]} rounded-full flex items-center justify-center`}>
                      <i className={`fas ${supplier.supplierType === 'rental' ? 'fa-truck' : supplier.supplierType === 'service' ? 'fa-cog' : 'fa-box'} text-xs`}></i>
                    </div>
                    <span className="text-foreground font-medium">{supplier.name}</span>
                    {supplier.monitored && (
                      <i className="fas fa-star text-yellow-500" title="Fornecedor monitorado"></i>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-mono">
                  {supplier.cnpj}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getSupplierTypeColor(supplier.supplierType)}`}>
                    {getSupplierTypeName(supplier.supplierType)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-medium">
                  {formatCurrency(supplier.contractBalance)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    supplier.monitored 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {supplier.monitored ? 'Sim' : 'Não'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <div className="flex gap-2">
                    <button 
                      onClick={() => onEdit(supplier)}
                      data-testid={`button-edit-${supplier.name.replace(/\s+/g, '-').toLowerCase()}`}
                      className="text-primary hover:text-primary/80" 
                      title="Editar"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button 
                      onClick={() => onView(supplier)}
                      data-testid={`button-view-${supplier.name.replace(/\s+/g, '-').toLowerCase()}`}
                      className="text-muted-foreground hover:text-foreground" 
                      title="Visualizar"
                    >
                      <i className="fas fa-eye"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
