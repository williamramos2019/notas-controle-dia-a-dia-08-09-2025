import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { InvoiceWithSupplier } from "@shared/schema";

interface InvoiceTableProps {
  invoices: InvoiceWithSupplier[];
  onEdit: (invoice: InvoiceWithSupplier) => void;
  onView: (invoice: InvoiceWithSupplier) => void;
}

export function InvoiceTable({ invoices, onEdit, onView }: InvoiceTableProps) {
  const getInvoiceTypeColor = (type: string) => {
    switch (type) {
      case 'contract': return 'bg-blue-100 text-blue-800 border-l-blue-500';
      case 'adhoc': return 'bg-purple-100 text-purple-800 border-l-purple-500';
      case 'rental': return 'bg-orange-100 text-orange-800 border-l-orange-500';
      default: return 'bg-gray-100 text-gray-800 border-l-gray-500';
    }
  };

  const getInvoiceTypeIcon = (type: string) => {
    switch (type) {
      case 'contract': return 'fas fa-file-contract';
      case 'adhoc': return 'fas fa-bolt';
      case 'rental': return 'fas fa-tools';
      default: return 'fas fa-file';
    }
  };

  const getInvoiceTypeName = (type: string) => {
    switch (type) {
      case 'contract': return 'Contrato';
      case 'adhoc': return 'Avulsa';
      case 'rental': return 'Locação';
      default: return type;
    }
  };

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return { text: `${Math.abs(diffDays)} dias vencido`, color: 'text-red-600 font-bold' };
    } else if (diffDays <= 5) {
      return { text: `${diffDays} dias restantes`, color: 'text-red-600 font-medium' };
    } else if (diffDays <= 10) {
      return { text: `${diffDays} dias restantes`, color: 'text-yellow-600 font-medium' };
    } else {
      return { text: `${diffDays} dias restantes`, color: 'text-green-600 font-medium' };
    }
  };

  const getStatusIcon = (status: boolean) => {
    return status 
      ? "inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800"
      : "inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800";
  };

  const formatCurrency = (value: string) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(parseFloat(value));
  };

  if (invoices.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <i className="fas fa-file-invoice text-4xl text-muted-foreground mb-4"></i>
        <h3 className="text-lg font-medium text-foreground mb-2">Nenhuma nota fiscal encontrada</h3>
        <p className="text-muted-foreground">Adicione uma nova nota fiscal para começar.</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground">Notas Fiscais - Alertas e Status</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Número
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Fornecedor</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Tipo</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Vencimento
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Valor</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Saldo Contrato</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="bg-background divide-y divide-border">
            {invoices.map((invoice) => {
              const daysInfo = getDaysUntilDue(invoice.dueDate.toString());
              const typeColor = getInvoiceTypeColor(invoice.invoiceType);
              const isOverdue = daysInfo.text.includes('vencido');
              
              return (
                <tr 
                  key={invoice.id} 
                  className={`hover:bg-accent/50 transition-colors border-l-4 ${typeColor.split(' ').pop()} ${isOverdue ? 'bg-red-50' : ''}`}
                  data-testid={`invoice-row-${invoice.invoiceNumber}`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{invoice.invoiceNumber}</span>
                      {(isOverdue || daysInfo.color.includes('red')) && (
                        <i className="fas fa-exclamation-triangle text-red-500" title={isOverdue ? "Vencido" : "Urgente"}></i>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 ${typeColor.split(' ')[0]} rounded-full flex items-center justify-center`}>
                        <i className={`${invoice.invoiceType === 'rental' ? 'fas fa-truck' : 'fas fa-building'} text-xs`}></i>
                      </div>
                      <span className="text-foreground font-medium">{invoice.supplier.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColor.split(' ').slice(0, 2).join(' ')}`}>
                      <i className={`${getInvoiceTypeIcon(invoice.invoiceType)} mr-1`}></i>
                      {getInvoiceTypeName(invoice.invoiceType)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm">
                      <div className="text-foreground font-medium">
                        {format(new Date(invoice.dueDate), 'dd/MM/yyyy', { locale: ptBR })}
                      </div>
                      <div className={daysInfo.color}>{daysInfo.text}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-medium">
                    {formatCurrency(invoice.value)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex gap-1">
                      <span className={getStatusIcon(invoice.posted ?? false)} title="Nota Lançada">
                        <i className={`fas ${invoice.posted ? 'fa-check' : 'fa-times'}`}></i>
                      </span>
                      <span className={getStatusIcon(invoice.attachmentUploaded ?? false)} title="Boleto Anexo">
                        <i className={`fas ${invoice.attachmentUploaded ? 'fa-check' : 'fa-times'}`}></i>
                      </span>
                      <span className={getStatusIcon(invoice.regularized ?? false)} title="Regularização">
                        <i className={`fas ${invoice.regularized ? 'fa-check' : 'fa-times'}`}></i>
                      </span>
                      <span className={getStatusIcon(invoice.measurementApproved ?? false)} title="Aprovação da Medição">
                        <i className={`fas ${invoice.measurementApproved ? 'fa-check' : 'fa-times'}`}></i>
                      </span>
                      <span className={getStatusIcon(invoice.measured ?? false)} title="Medido">
                        <i className={`fas ${invoice.measured ? 'fa-check' : 'fa-times'}`}></i>
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                    {invoice.contractBalance ? formatCurrency(invoice.contractBalance) : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => onEdit(invoice)}
                        data-testid={`button-edit-${invoice.invoiceNumber}`}
                        className="text-primary hover:text-primary/80" 
                        title="Editar"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        onClick={() => onView(invoice)}
                        data-testid={`button-view-${invoice.invoiceNumber}`}
                        className="text-muted-foreground hover:text-foreground" 
                        title="Visualizar"
                      >
                        <i className="fas fa-eye"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
