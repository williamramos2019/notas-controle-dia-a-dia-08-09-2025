# Overview

This is a comprehensive Invoice Control System ("Controle de Notas Fiscais") built with modern web technologies. The system manages invoice processing, supplier information, and provides real-time alerts for financial tracking and compliance. It features a React-based frontend with shadcn/ui components and an Express.js backend using PostgreSQL with Drizzle ORM for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Styling**: Tailwind CSS with shadcn/ui component library providing consistent design system
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for robust form management

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Database**: PostgreSQL with Neon serverless for scalable data storage
- **ORM**: Drizzle ORM with type-safe database operations and migrations
- **API Design**: RESTful endpoints for suppliers, invoices, and dashboard metrics
- **Development**: Hot reload with Vite middleware integration

## Database Schema
The system uses three main entities:
- **Suppliers**: Store company information, contract balances, and monitoring preferences
- **Invoices**: Track invoice details, status checkboxes, and financial data
- **Alerts**: Manage due date notifications and priority alerts

## Component Architecture
- **Layout Components**: Sidebar navigation and header with notification system
- **Page Components**: Dashboard, invoices, suppliers, and reports sections
- **UI Components**: Comprehensive shadcn/ui component library for consistent interface
- **Form Components**: Modular forms for invoice and supplier data entry

## Key Features
- **Invoice Management**: Support for contract, adhoc, and rental invoice types
- **Supplier Database**: CNPJ validation, contract balance tracking, and monitoring flags
- **Status Tracking**: Checkbox system for invoice processing stages
- **Alert System**: Automated due date notifications and priority alerts
- **Dashboard Metrics**: Real-time statistics and financial summaries

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

## UI Framework
- **Radix UI**: Headless component primitives for accessible user interfaces
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind

## Development Tools
- **TypeScript**: Static type checking for improved code quality
- **Vite**: Modern build tool with fast HMR and optimized builds
- **ESBuild**: Fast JavaScript bundler for production builds

## Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## Date Handling
- **date-fns**: Modern JavaScript date utility library with Portuguese locale support

## Development Environment
- **Replit Integration**: Development environment support with runtime error overlay
- **Cartographer**: Replit-specific tooling for enhanced development experience