===============================================
    SISTEMA CONTROLE DE NOTAS FISCAIS
        Pronto para cPanel/Hostgator
===============================================

📋 INSTALAÇÃO RÁPIDA:

1. Faça upload da pasta "public_html" para seu cPanel
2. Acesse: seudominio.com/api/init_database.php
3. Após inicializar, DELETE o arquivo init_database.php
4. Acesse: seudominio.com

📁 ESTRUTURA:
- public_html/           -> Upload completo para cPanel
- INSTRUCOES_INSTALACAO.md -> Guia detalhado

💻 TECNOLOGIAS:
- Frontend: React + TypeScript + Vite + Tailwind
- Backend: PHP 8 + SQLite
- Responsivo e otimizado

✅ FUNCIONALIDADES:
- Dashboard com métricas
- Gestão de notas fiscais  
- Cadastro de fornecedores
- Sistema de alertas
- Filtros avançados

🔧 REQUISITOS:
- PHP 7.4+ 
- SQLite habilitado
- mod_rewrite ativo

📞 SUPORTE:
Leia INSTRUCOES_INSTALACAO.md para detalhes completos

Desenvolvimento: React + TypeScript + Vite + PHP
Compatível: cPanel, Hostgator, e hospedagens similares