# 📋 Instruções de Instalação - Sistema Controle de Notas Fiscais

## 🎯 Sobre o Sistema

Sistema completo para controle e gerenciamento de notas fiscais desenvolvido com **React + TypeScript + Vite** no frontend e **PHP + SQLite** no backend, otimizado para hospedagem cPanel (Hostgator e similares).

## 📦 Conteúdo do Pacote

```
cpanel-deploy/
├── public_html/                 # Pasta principal para upload
│   ├── index.html              # Página principal da aplicação
│   ├── assets/                 # Assets do React (CSS/JS)
│   ├── api/                    # Backend PHP
│   │   ├── config.php          # Configuração do banco SQLite
│   │   ├── suppliers.php       # API de fornecedores
│   │   ├── invoices.php        # API de notas fiscais
│   │   ├── dashboard.php       # API do dashboard
│   │   ├── init_database.php   # Script de inicialização
│   │   └── .htaccess          # Configuração da API
│   └── .htaccess              # Configuração principal
└── INSTRUCOES_INSTALACAO.md   # Este arquivo
```

## 🚀 Passo a Passo da Instalação

### 1. **Preparar o cPanel**
   - Acesse o **Gerenciador de Arquivos** do cPanel
   - Navegue até a pasta `public_html`
   - **Faça backup** dos arquivos existentes (se necessário)
   - **Limpe a pasta** `public_html` (ou crie uma subpasta)

### 2. **Upload dos Arquivos**
   - Faça upload de **todo o conteúdo** da pasta `public_html`
   - Mantenha a estrutura de pastas exatamente como está
   - Verifique se as pastas `api` e `assets` foram criadas corretamente

### 3. **Configurar Permissões**
   - Acesse **Gerenciador de Arquivos** → `public_html/api`
   - Selecione o arquivo `config.php`
   - Clique em **Permissões** e defina como **644**
   - Faça o mesmo para todos os arquivos `.php` na pasta `api`

### 4. **Inicializar o Banco de Dados**
   - Acesse: `https://seudominio.com/api/init_database.php`
   - O script criará automaticamente:
     - ✅ Banco SQLite com todas as tabelas
     - ✅ Dados de exemplo (fornecedores e notas)
     - ✅ Estrutura completa do sistema
   
   **⚠️ IMPORTANTE:** Após a inicialização, **delete o arquivo** `init_database.php` por segurança!

### 5. **Testar o Sistema**
   - Acesse: `https://seudominio.com`
   - Verifique se a página carrega corretamente
   - Teste a navegação entre as seções:
     - 📊 **Dashboard** - Métricas e alertas
     - 📄 **Notas Fiscais** - Gerenciar notas
     - 🏢 **Fornecedores** - Cadastro de fornecedores

## 🔧 Configurações Avançadas

### **Personalizar Domínio/Subpasta**
Se instalar em subpasta (ex: `seudominio.com/sistema`):
1. Crie a pasta `sistema` em `public_html`
2. Faça upload dos arquivos dentro dela
3. Acesse: `https://seudominio.com/sistema`

### **Permissões do SQLite**
- A pasta `api` precisa ter permissão de **escrita** (755)
- O arquivo `database.sqlite` será criado automaticamente
- Em caso de erro, verifique as permissões da pasta

### **SSL/HTTPS**
- O sistema funciona em HTTP e HTTPS
- Para maior segurança, force HTTPS no cPanel
- Adicione certificado SSL gratuito (Let's Encrypt)

## 🛠️ Funcionalidades do Sistema

### **✅ Dashboard Completo**
- Métricas em tempo real
- Alertas de vencimento
- Filtros avançados
- Busca inteligente

### **✅ Gestão de Notas Fiscais**
- Cadastro manual completo
- Tipos: Contrato, Avulsa, Locação
- Status: Lançada, Boleto, Regularização, etc.
- Alertas visuais por vencimento

### **✅ Cadastro de Fornecedores**
- Validação de CNPJ
- Tipos: Locação, Serviço, Produto
- Saldo de contrato
- Sistema de monitoramento

### **✅ Sistema de Alertas**
- Notificações de vencimento
- Cores diferenciadas por urgência
- Fornecedores prioritários

## 📊 Requisitos Técnicos

### **Servidor (cPanel/Hostgator)**
- ✅ **PHP 7.4+** (recomendado 8.0+)
- ✅ **SQLite** habilitado
- ✅ **mod_rewrite** ativo
- ✅ **HTTPS** (recomendado)

### **Navegador**
- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## 🔍 Solução de Problemas

### **❌ Página em branco**
1. Verifique se todos os arquivos foram uploadados
2. Confirme as permissões dos arquivos PHP
3. Ative o modo de depuração no cPanel

### **❌ Erro 500 na API**
1. Verifique as permissões da pasta `api` (755)
2. Confirme se o PHP SQLite está habilitado
3. Verifique os logs de erro do cPanel

### **❌ "Erro na conexão"**
1. Execute novamente o `init_database.php`
2. Verifique se a pasta `api` tem permissão de escrita
3. Contate o suporte da hospedagem se persistir

### **❌ Rotas não funcionam**
1. Verifique se o arquivo `.htaccess` foi uploadado
2. Confirme se o `mod_rewrite` está ativo
3. Teste em modo de compatibilidade

## 📞 Suporte

### **Logs e Depuração**
- Logs do PHP: `cPanel → Logs de Erro`
- Console do navegador: `F12 → Console`
- Teste da API: `https://seudominio.com/api/suppliers.php`

### **Backup e Restauração**
- **Backup regular**: Faça download da pasta `public_html`
- **Banco de dados**: O arquivo `database.sqlite` contém todos os dados
- **Restauração**: Faça upload dos arquivos de backup

## 🎉 Pronto!

Seu sistema **Controle de Notas Fiscais** está instalado e funcionando!

**Próximos passos:**
1. 🔐 Remova o arquivo `init_database.php`
2. 📋 Cadastre seus fornecedores reais
3. 📄 Comece a inserir suas notas fiscais
4. 📊 Monitore os alertas no dashboard

---

**💡 Dica:** Marque este arquivo como favorito para consultas futuras sobre manutenção e atualizações do sistema.